/*<============== CREDITS ==============>
        Author: berkahesport
        Github: https://github.com/BerkahEsport/
        Contact me: 6289654279897

        Do not delete the source code.
        It is prohibited to
        sell and buy scripts
        without the knowledge
        of the script owner.

        Thank you to Allah S.W.T
<============== CREDITS ==============>*/

export default {
name: "",
command: [""],
tags: "",
desc: "",
customPrefix: "",
example: "",
limit: false,
isOwner: false,
isPremium: false,
isBotAdmin: false,
isAdmin: false,
isGroup: false,
isPrivate: false,
run: async(m, {
    prefix,
    noPrefix,
    command,
    arg,
    args,
    text,
    sock,
    commands,
    cmd,
    name,
    user,
    settings,
    stats,
    isQuoted,
    isGroup,
    isAdmin,
    isBotAdmin,
    admin,
    metadata,
    participants,
    store,
    config,
    functions,
    axios,
    cheerio
}) => {
}
}